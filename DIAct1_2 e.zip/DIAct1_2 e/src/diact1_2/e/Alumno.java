/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diact1_2.e;

/**
 *
 * @author carloseg
 */
public class Alumno {
    private String nombre;
    private String apellidos;
    private String email;
    private int edad;
    private String telefono;
    
    public Alumno()
    {
        
    }
    
    public Alumno(String nombre, String apellidos, int edad)
    {
        nombre = nombre;
        apellidos = apellidos;
        edad = edad;
        
    }
    
    public Alumno(String nombre, String apellidos, String email, int edad, String telefono)
    {
        nombre = nombre;
        apellidos = apellidos;
        email = email;
        edad = edad;
        telefono = telefono;
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
     public String mayoredad (String nombre, String apellidos, int edad){
        String esmayor;
        if (edad >= 18){
            esmayor = "El alumno "+ nombre +" "+ apellidos + " es mayor de edad";
        }
        else {
            esmayor = "El alumno "+ nombre +" "+ apellidos + " no es mayor de edad";
        }
        return esmayor;
    }
    
}
