/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diact1_2.e;

import java.util.Scanner;
import javax.swing.SwingUtilities;

/**
 *
 * @author carloseg
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->new JFrameAlumno().Mostrar());
        Scanner teclado = new Scanner(System.in);
        char respu = ' ';
        String nombre = null, apellidos = null, esMayor;
        int edad = 0; 
        int contaalu = 0, pos = 0, masjoven = 99999999;
        Alumno alumno = new Alumno();
        Alumno[] alu = new Alumno[5];
        do {
            for (int i = 0; i < alu.length; i++) {
                alu[i] = new Alumno();
                System.out.println("Introducir nombre del alumno");
                nombre = teclado.nextLine();
                alu[i].setNombre(nombre);
                System.out.println("Introducir apellidos del alumno");
                apellidos = teclado.nextLine();
                alu[i].setApellidos(apellidos);
                System.out.println("Introducir edad del alumno");
                edad = teclado.nextInt();
                
                while (edad < 0){
                    System.out.println("Error. Introduce un numero mayor de 0");
                    edad = teclado.nextInt();
                }
                
                alu[i].setEdad(edad);
                teclado.nextLine();
               
                esMayor = alumno.mayoredad(nombre, apellidos, edad);
                System.out.println(esMayor);
                contaalu++;
                System.out.println();
            }
            for (int i = 0; i < alu.length; i++) {
                 if (alu[i].getEdad() < masjoven) {
                    masjoven = alu[i].getEdad();
                    pos = i;
                   
                }
            }
            System.out.println("El alumno mas joven es " + alu[pos].getNombre() + " " + alu[pos].getApellidos() + " y su edad es " + alu[pos].getEdad()+" años");
            System.out.println();
            System.out.println("¿Quieres agregar mas alumnos (S/N):? ");
            respu = teclado.next().charAt(0);
            respu = Character.toUpperCase(respu);
            teclado.nextLine();
            while ((respu != 'S') && (respu != 'N')) {
                System.out.println("Error teclea (S/N): ");
                respu = teclado.next().charAt(0);
                respu = Character.toUpperCase(respu);
                teclado.nextLine();
            }
            
        } while (respu == 'S' && contaalu < alu.length);
        if (respu == 'N') {
            System.out.println("FIN OPERACIONES");
        }
        else if (contaalu >= alu.length) {
                System.out.println("El numero de alumnos que se puede registrar no puede ser superior a 5");
                System.out.println("FIN OPERACIONES");
            }
    }

}
